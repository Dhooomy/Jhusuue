package com.dahemia.vcamhelper;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    private static final int PICK_VIDEO_REQUEST = 101;
    private static final int OVERLAY_PERMISSION_REQUEST = 102;
    private TextView txtStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnPick = findViewById(R.id.btnPickVideo);
        Button btnDelete = findViewById(R.id.btnDeleteVideo);
        Button btnToggleFloating = findViewById(R.id.btnToggleFloating);
        txtStatus = findViewById(R.id.txtStatus);

        checkOverlayPermission();

        btnPick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("video/*");
                startActivityForResult(Intent.createChooser(intent, "اختر فيديو VCAM"), PICK_VIDEO_REQUEST);
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteCurrentVideo();
            }
        });

        btnToggleFloating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, FloatingService.class);
                startService(intent);
                Toast.makeText(MainActivity.this, "تم تفعيل النافذة العائمة 🚀", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri videoUri = data.getData();
            if (videoUri != null) {
                saveVideoToVCAM(videoUri);
            }
        }
    }

    private void saveVideoToVCAM(Uri uri) {
        try {
            File targetDir = new File("/sdcard/DCIM/Camera1/");
            if (!targetDir.exists()) {
                targetDir.mkdirs();
            }

            File targetFile = new File(targetDir, "virtual.mp4");
            InputStream inputStream = getContentResolver().openInputStream(uri);
            OutputStream outputStream = new FileOutputStream(targetFile);

            byte[] buffer = new byte[2048];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }

            outputStream.flush();
            outputStream.close();
            inputStream.close();

            txtStatus.setText("الحالة: تم تعيين الفيديو الحالي جاهزاً للمحاكاة ✅");
            Toast.makeText(this, "تم تغيير الفيديو بنجاح!", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            txtStatus.setText("خطأ: " + e.getMessage());
        }
    }

    private void deleteCurrentVideo() {
        File file = new File("/sdcard/DCIM/Camera1/virtual.mp4");
        if (file.exists() && file.delete()) {
            txtStatus.setText("الحالة: تم مسح الفيديو المفعل 🗑️");
            Toast.makeText(this, "تم تفريغ مسار الكاميرا!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "لا يوجد فيديو حالي للمسح!", Toast.LENGTH_SHORT).show();
        }
    }
}
